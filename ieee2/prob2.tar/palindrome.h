#ifndef PALINDROME_H
#define PALINDROME_H

#include <string.h>
bool ispalindrome(const char *);

#endif
